// Import the functions you need from the SDKs you need

import { initializeApp } from "firebase/app";

import { getAnalytics } from "firebase/analytics";

import { getFirestore } from "firebase/firestore"; // Import Firestore

import { getAuth } from "firebase/auth"; // Import Authentication



// TODO: Add SDKs for Firebase products that you want to use

// https://firebase.google.com/docs/web/setup#available-libraries


// Your web app's Firebase configuration

// For Firebase JS SDK v7.20.0 and later, measurementId is optional

const firebaseConfig = {

  apiKey: "AIzaSyBAijeRsJDfLl1IQzX2beIHXEspcth9n7o",

  authDomain: "hackathonreactnativeapp.firebaseapp.com",

  projectId: "hackathonreactnativeapp",

  storageBucket: "hackathonreactnativeapp.firebasestorage.app",

  messagingSenderId: "741772494809",

  appId: "1:741772494809:web:ec11fd07269fa2cb10bbc8",

  measurementId: "G-TYQFT84QB1"

};


// Initialize Firebase

const app = initializeApp(firebaseConfig);

const analytics = getAnalytics(app);

const db = getFirestore(app); // Initialize Firestore

const auth = getAuth(app);   // Initialize Authentication

// Export the initialized modules if you need to use them in other files
export { db, auth };