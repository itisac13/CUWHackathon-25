import { StyleSheet, Text, View, TextInput, Button} from 'react-native'
// import { auth } from './firebaseConfig';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect, useCallback } from 'react';
import {
  SafeAreaView,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithIdToken,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';

// Replace with your Firebase configuration
const firebaseConfig = {

    apiKey: "AIzaSyBAijeRsJDfLl1IQzX2beIHXEspcth9n7o",
  
    authDomain: "hackathonreactnativeapp.firebaseapp.com",
  
    projectId: "hackathonreactnativeapp",
  
    storageBucket: "hackathonreactnativeapp.firebasestorage.app",
  
    messagingSenderId: "741772494809",
  
    appId: "1:741772494809:web:ec11fd07269fa2cb10bbc8",
  
    measurementId: "G-TYQFT84QB1"
  
  };
  

// Initialize Firebase if not already initialized
let firebaseApp;
if (!firebaseApp) {
  firebaseApp = initializeApp(firebaseConfig);
}

const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

const index = () => {
  const [user, setUser] = useState(null);
  const [newsFeed, setNewsFeed] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [likes, setLikes] = useState([]);
  const [recentSearches, setRecentSearches] = useState([]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      if (authUser) {
        setUser(authUser);
        await loadUserData(authUser.uid);
        await fetchNews(authUser.uid);
      } else {
        setUser(null);
        setNewsFeed([]);
        setLikes([]);
        setRecentSearches([]);
      }
    });

    return () => unsubscribe();
  }, []);

  const loadUserData = useCallback(async (uid) => {
    try {
      const userDocRef = doc(db, 'users', uid);
      const userDocSnap = await getDoc(userDocRef);
      if (userDocSnap.exists()) {
        const userData = userDocSnap.data();
        setLikes(userData.likes || []);
        setRecentSearches(userData.recent_searches || []);
      } else {
        // Create user document if it doesn't exist (with default role)
        const authUser = auth.currentUser;
        if (authUser) {
          await setDoc(doc(db, 'users', uid), {
            email: authUser.email,
            role: 'base_user', // Default role
            likes: [],
            recent_searches: [],
          });
          setLikes([]);
          setRecentSearches([]);
        }
      }
    } catch (e) {
      console.error('Error loading user data:', e);
      setError('Failed to load user data.');
    }
  }, []);

  const fetchNews = useCallback(async (uid) => {
    setLoading(true);
    setError(null);
    try {
      const idToken = await auth.currentUser?.getIdToken();
      if (idToken) {
        // Replace with your backend API endpoint for fetching news
        const response = await fetch('YOUR_BACKEND_API_URL/news', {
          headers: {
            Authorization: `Bearer ${idToken}`,
          },
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setNewsFeed(data);
      }
    } catch (e) {
      console.error('Error fetching news:', e);
      setError('Failed to fetch news.');
    } finally {
      setLoading(false);
    }
  }, []);

  const handleUpdatePreferences = useCallback(async () => {
    if (user) {
      try {
        const userDocRef = doc(db, 'users', user.uid);
        await setDoc(userDocRef, { likes, recentSearches }, { merge: true });
        alert('Preferences updated!');
      } catch (e) {
        console.error('Error updating preferences:', e);
        setError('Failed to update preferences.');
      }
    }
  }, [user, likes, recentSearches]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Error signing out:', e);
      setError('Failed to logout.');
    }
  };

  const renderNewsItem = ({ item }) => (
    <View style={styleSheet.newsItem}>
      <Text style={styleSheet.title}>{item.title}</Text>
      <Text style={styleSheet.summary}>{item.summary}</Text>
      <Text style={styleSheet.published}>{item.published}</Text>
      {/* You might want to make the title clickable to open the full article */}
    </View>
  );

  if (loading) {
    return (
      <SafeAreaView style={styleSheet.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styleSheet.container}>
        <Text style={styleSheet.error}>{error}</Text>
        {user && <Button title="Retry Fetch News" onPress={() => fetchNews(user.uid)} />}
      </SafeAreaView>
    );
  }

  if (!user) {
    // In a real app, you would have a proper login screen with Firebase UI or custom UI
    return (
      <SafeAreaView style={styleSheet.container}>
        <Text>Please log in.</Text>
        {/* You would integrate Firebase Authentication UI (e.g., using a WebView or a native library) here.
            The successful sign-in would provide an ID token that you can then use to call your backend
            and potentially use `signInWithIdToken` on the frontend (though typically the session is managed
            on the backend after verifying the token). */}
        {/* Example button to trigger a hypothetical login (replace with actual Firebase UI integration) */}
        <Button
          title="Simulate Login (Replace with Firebase UI)"
          onPress={async () => {
            let email = "poop@poop.com"
            let password = "poop123"
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const IdToken = await userCredential.user.getIdToken();
            // In a real scenario, you'd get the ID token from Firebase UI
            // const IdToken = 'bcqLbmjUMwShHWZwLXQCTnsJmJW2'; // Replace with a real ID token for testing
            
            if (IdToken !== 'YOUR_DUMMY_ID_TOKEN') {
              try {
                await signInWithIdToken(auth, IdToken);
              } catch (error) {
                console.error('Error signing in with ID token:', error);
                setError('Failed to sign in.');
              }
            } else {
              alert('Replace the dummy ID token with a real one for testing.');
            }
          }}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styleSheet.container}>
      <View style={styleSheet.header}>
        <Text style={styleSheet.headerText}>News Feed</Text>
        <Button title="Logout" onPress={handleLogout} />
      </View>

      <FlatList
        data={newsFeed}
        renderItem={renderNewsItem}
        keyExtractor={(item, index) => index.toString()}
      />

      {/* Conditional rendering for Pro User preferences */}
      {likes !== undefined && recentSearches !== undefined && (
        <View style={styleSheet.preferencesContainer}>
          <Text style={styleSheet.preferencesTitle}>Update Preferences (Pro User)</Text>
          <TextInput
            style={styleSheet.input}
            placeholder="Likes (comma-separated)"
            value={likes.join(', ')}
            onChangeText={(text) => setLikes(text.split(',').map((item) => item.trim()))}
          />
          <TextInput
            style={styleSheet.input}
            placeholder="Recent Searches (comma-separated)"
            value={recentSearches.join(', ')}
            onChangeText={(text) => setRecentSearches(text.split(',').map((item) => item.trim()))}
          />
          <Button title="Update Preferences" onPress={handleUpdatePreferences} />
        </View>
      )}
    </SafeAreaView>
  );
};

const styleSheet = StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: 20,
      paddingHorizontal: 10,
      backgroundColor: '#1E2A38', // Midnight Mist for the background
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
    },
    headerText: {
      fontSize: 20,
      fontWeight: 'bold',
      color: '#F8F9FA', // Glacier White for header text
    },
    newsItem: {
      backgroundColor: '#ECEFF4', // Frost Gray for card surfaces
      padding: 15,
      marginBottom: 10,
      borderRadius: 5,
    },
    title: {
      fontSize: 18,
      fontWeight: 'bold',
      marginBottom: 5,
      color: '#2E3440', // Deep Slate for title text
    },
    summary: {
      fontSize: 14,
      marginBottom: 5,
      color: '#2E3440', // Deep Slate for summary text
    },
    published: {
      fontSize: 12,
      color: '#D08770', // Aurora Pink for the published date text
    },
    error: {
      color: '#D08770', // Aurora Pink for error text
      marginBottom: 10,
    },
    preferencesContainer: {
      marginTop: 20,
      padding: 15,
      backgroundColor: '#ECEFF4', // Frost Gray for preferences container
      borderRadius: 5,
    },
    preferencesTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      marginBottom: 10,
      color: '#F8F9FA', // Glacier White for preferences title text
    },
    input: {
      height: 40,
      borderColor: '#A3BE8C', // Aurora Green for input border
      borderWidth: 1,
      marginBottom: 10,
      paddingHorizontal: 10,
      borderRadius: 5,
    },
  });
  

export default index;


/*import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text>HEllO GAMERS! You are diagnosed with testicular cancer and autism.</Text>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
*/
